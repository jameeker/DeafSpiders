# PROJECT TITLE

Deaf Spiders: Kent State Fashion-Tech Hackathon Team #13
A wearable and fashionable headpiece that allows everyday users to interact with music through vibrations and visual aesthetics specifically designed for those who have accessibility issues.

# PROJECT DESCRIPTION

Deaf Spiders is group #13's team name. Our project revolves around creating a visual, auditory, and sensory headpiece that has the ability to clip onto any headphone of any kind. This wearable headpiece technology allows everyday users to interact with music in a much more engaging manner, tapping into multiple sensory elements through vibrations and visual aesthetics, especially effective for those with auditory and visual impairments. 

# CODE DESCRIPTION: WHAT IT DOES, HOW IT WORKS, ETC.

For our prototype and demonstration, numerous parts of code are all inter-connected and dependent on each other. The main purpose and function of our code are to take audio frequency information and translate it into physical movement through hardware. The 3 main parts of team Deaf Spider's code to achieve this function is 

    1. p5.js FFT spectrum audio visualization javascript code
    2. python to organize and work on data
    3. Arduino serial communication and JSON to operate motor (physical) movement

___________________________________________________________________________________________________________

P5.JS SECTION

The 'analyzer' folder which includes index.html and sketch.js is code for p5.js, this code uses
a computer's default input microphone and record sound from the room. The code was tested with a MacBook Pro microphone for demonstration purposes. The audio visualizer spectrum that is displayed on the canvas in p5.js represents all audio frequencies present that can be heard and detected from your computer's microphone. The visualizer itself is split into 16 poles, the red (leftmost pole) represents the lowest frequencies [0 - 200 Hz] and the magenta pole represents the high frequencies [15 kHz - inf].

In sketch.js, the FFT library is used which is responsible for all necessary frequency analysis. FFT = Fast Fourier Transform
A canvas is created, and the code records computer audio, uses FFT to analysis frequencies and necessary audio information, and displays that information accurately in a concise manner with 16 poles that correspond to frequency ranges i.e. lows, mids, and highs.

All frequency information is logged in the p5 console.
example: [223,206,150,78,73,68,60,41,16,0,0,0,0,0,0,0]

___________________________________________________________________________________________________________

PYTHON SECTION

Once audio frequencies could be reliably gathered through FFT, room ambiance and noise were gathered and recorded from the p5.js console and it was imported and worked with in python code. This code prints the frequency of the input audio in real-time using Fast Fourier Transform (FFT)
To achieve this, PyAudio was used for recording and playing audio, Wave for working with WAV audio files, SciPy for signal processing, and NumPy for numerical operations.

The code sets the parameters for recording (chunk size, format, channels, rate, and duration) and then initializes PyAudio to open and start audio recording. PyAudio is a Python wrapper for the PortAudio cross-platform audio I/O library. It then initializes PyAudio and gets information about the available host APIs using the get_host_api_info_by_index method. The code reads the audio data in chunks, computes the FFT of the data, and prints the frequency of the input audio. Once the recording is complete, the code stops the audio stream, terminates PyAudio, and saves the recorded audio to a WAV file using Wave. In this case, an extensive log of audio frequency data was gathered from a pre-recorded audio file for demonstration.

for the "getinput.py" file, simply, helps provide a convenient way to list all available input audio devices on a computer, which can be useful when working with audio applications that require device selection.

___________________________________________________________________________________________________________

ARDUINO SECTION

To stay true to our headset's purposes, one feature that is demonstrated is the ability to hear and take in auditory input and eventually translate that input (audio frequencies) into real, physical motor movement. This was conceptualized and achieved through the use of Arduino and servo motors. Servo motors serve the purpose of providing vibration and also moving the wings/legs of our design in a multi-directional way.

With the logged frequency data, that data was essentially mapped to 3 Arduino Uno servo motors (strictly for this demonstration, the final design could have supported more motors). This data was then converted into serial input which is used to control and direct the motors. See 'servo_driver_copy_20230319000434' folder for code written in the Arduino IDE.

This code handles all necessary serial communication and JSON data.

# PROJECT PURPOSE, OUTREACH, AND CHALLENGE

We value a more fair and accessible society and would love to serve those with disabilities or struggles with accessibility such as the deaf. The challenge Deaf Spiders is competing in is the "Wear Your Music Maker". 

2023 Wear Your Music Maker Challenge's description is the following:

 Make your garment or wearable an instrument. How might we use our bodies, garments, and technology to create new music makers? What might a performance look like? How might we make new music together with our clothing?
 Tags: music, exploration, performance, sound, gesture-based controls.

Additionally, the Deaf Spiders concept may fit into the "Utilizing Wearable Technology to Connect and Collaborate" challenge as well, as it works to help wearers connect through music in very tangible and social ways.

# PRACTICALITY AND VISIONS FOR FUTURE VERSIONS

Ideally, with more time this code would be able to read in highly detailed audio files, live audio (both internally and externally sourced) from the Deaf Spiders headpiece design, and more intricate movements, features, and capabilities would be present. The servo motor functionality would be expanded upon and leg/wing movements would be multidirectional and be completely controlled by audio of any form (music, ambience, background noise, speech, specific frequencies, etc.)

In the future, there could be a sync feature and communal aspect as there would be multiple people with headpieces. An example would be at a music concert, rave, or dance festival multiple wearers of the headpiece would be in sync if in close proximity. Movement of the legs would be synced amongst wearers.

Additionally, there are plans to add LED lighting which would aid to the cohesiveness of the design, more sensors that would provide aid for accessibility purposes (such as vibrations), and any other aesthetically robust features that may add to the product.

# CREDITS

Code and documentation written by Jaime Meeker, an Engineering and Computer Science participant in the 2023 Kent State University Fashion-Tech Hackathon representing Team #13 Deaf Spiders.