let mic, fft;
let width = 800;
let height = 400;

function setup() {
  createCanvas(width, 400);
  noFill();

  mic = new p5.AudioIn();
  mic.start();
  fft = new p5.FFT(.8,16);
  fft.setInput(mic);
  colorMode(HSB, width);
}

function draw() {
  background(200);

  let spectrum = fft.analyze();

  // beginShape();
  // console.log(spectrum)
  for (i = 0; i < spectrum.length; i++) {
    let bgColor = color(i * 50, 800, 800);
    fill(bgColor); 
    //vertex(i, map(spectrum[i], 0, 255, height, 0));
    
    rect(i * 50, 400-map(spectrum[i], 0, 255, 0, 400), 50, map(spectrum[i], 0, 255, 0, 400));
  }
  // endShape();
}
